package br.edu.ifsp.spo.java.cards.itens;

public enum Naipe {
    COPAS, OUROS, PAUS, ESPADAS;
}
